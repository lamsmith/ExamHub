using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamHub.Entity
{
    public class ExamAnswer
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public ExamQuestion Question { get; set; }
        public string AnswerText { get; set; }
        public bool IsCorrect { get; set; }
    }
}